const API_BASE_URL = import.meta.env.VITE_API_BASE_URL

if (!API_BASE_URL) {
  throw new Error('❌ VITE_API_BASE_URL non défini dans .env')
}

// ===== Utilitaire de délai d'attente =====
function timeout(ms: number) {
  return new Promise((_, reject) =>
    setTimeout(() => reject(new Error('⏳ Délai dépassé')), ms)
  )
}

// ================== TOURNEES ==================
export async function fetchTournees() {
  const res = await fetch(`${API_BASE_URL}/tournees`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function ajouterTournee(tournee: any) {
  const res = await fetch(`${API_BASE_URL}/tournees`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(tournee),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function updateTournee(id: string, tournee: any) {
  const res = await fetch(`${API_BASE_URL}/tournees/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(tournee),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function deleteTournee(id: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== CONDUCTEURS ==================
// Liste des conducteurs
export async function fetchConducteurs() {
  const res = await fetch(`${API_BASE_URL}/tournees/conducteurs`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Ajouter un conducteur
export async function ajouterConducteur(conducteur: any) {
  const res = await fetch(`${API_BASE_URL}/conducteurs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(conducteur),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Update conducteur
export async function updateConducteur(id: string, conducteur: any) {
  const res = await fetch(`${API_BASE_URL}/conducteurs/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(conducteur),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Delete conducteur
export async function deleteConducteur(id: string) {
  const res = await fetch(`${API_BASE_URL}/conducteurs/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== AFFECTATIONS TOURNEES CONDUCTEUR ==================
// Liste tournées affectées
export async function fetchAffectationsConducteur(conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/affectations-conducteur/${conducteurId}`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Affecter à une tournée

// Retirer une affectation
export async function retirerAffectationConducteur(id: string) {
  const res = await fetch(`${API_BASE_URL}/affectations-conducteur/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== VEHICULES ==================
// Liste des véhicules
export async function fetchVehicules() {
  const res = await fetch(`${API_BASE_URL}/vehicules`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Ajouter un véhicule (optionnel)
export async function ajouterVehicule(vehicule: any) {
  const res = await fetch(`${API_BASE_URL}/vehicules`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(vehicule),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function updateVehicule(id: string, vehicule: any) {
  const res = await fetch(`${API_BASE_URL}/vehicules/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(vehicule),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function deleteVehicule(id: string) {
  const res = await fetch(`${API_BASE_URL}/vehicules/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== AFFECTATIONS VEHICULES CONDUCTEUR ==================
// Liste des véhicules affectés à un conducteur
export async function fetchVehiculesAffectes(conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/conducteur-vehicule/${conducteurId}`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Affecter véhicule à conducteur
export async function affecterVehiculeConducteur(payload: { conducteur_id: string, vehicule_id: string }) {
  const res = await fetch(`${API_BASE_URL}/conducteur-vehicule`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const err = await res.text()
    throw new Error(err || 'Erreur lors de l’affectation véhicule')
  }
  return res.json()
}
// Retirer affectation véhicule
export async function retirerAffectationVehiculeConducteur(id: string) {
  const res = await fetch(`${API_BASE_URL}/conducteur-vehicule/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// =======================EMPLOYES=================
export async function fetchEmployes() {
  const res = await fetch(`${API_BASE_URL}/employes`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function ajouterEmploye(employe: any) {
  const res = await fetch(`${API_BASE_URL}/employes`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(employe),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function updateEmploye(id: string, employe: any) {
  const res = await fetch(`${API_BASE_URL}/employes/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(employe),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function deleteEmploye(id: string) {
  const res = await fetch(`${API_BASE_URL}/employes/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// =======================AFFECTATIONS EMPLOYE==================
export async function fetchAffectationsEmploye(employeId: string) {
  const res = await fetch(`${API_BASE_URL}/affectations/${employeId}`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function ajouterAffectation(payload: {
  employe_id: string,
  type: 'fixe' | 'flexible',
  point_arret_id?: string,
  tournee_id: string,
  ordre_embarquement?: number
}) {
  const res = await fetch(`${API_BASE_URL}/affectations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const err = await res.text()
    throw new Error(err || 'Erreur lors de l’affectation')
  }
  return res.json()
}
export async function retirerAffectation(id: string, type: 'fixe' | 'flexible') {
  const res = await fetch(`${API_BASE_URL}/affectations/${id}?type=${type}`, {
    method: 'DELETE',
  })
  if (!res.ok) {
    const errText = await res.text()
    throw new Error(errText || 'Erreur lors de la suppression')
  }
  return res.json()
}
export async function updateAffectation(id: string, payload: { type: 'fixe' | 'flexible', point_arret_id?: string, ordre_embarquement?: number }) {
  const response = await fetch(`${API_BASE_URL}/affectations/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  const data = await response.json()
  if (!response.ok) {
    throw new Error(data.error || 'Erreur lors de la mise à jour de l’affectation')
  }
  return data
}

// ======================= POINTS D'ARRET ======================
export async function fetchPointsArretParTournee(tourneeId: string) {
  const res = await fetch(`${API_BASE_URL}/points-arret?tournee_id=${tourneeId}`)
  if (!res.ok) throw new Error('Erreur lors du chargement des points d’arrêt')
  return res.json()
}



// ================== AFFECTATIONS TOURNEES CONDUCTEUR ==================
/**
 * Récupère la liste des tournées affectées à un conducteur (champ conducteur_id)
 * Appelle l'endpoint : GET /tournees/conducteur/:conducteurId
 */
export async function fetchTourneesParConducteur(conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/conducteur/${conducteurId}`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

/**
 * Récupère la liste des tournées NON affectées à un conducteur (conducteur_id null)
 * Appelle l'endpoint : GET /tournees/disponibles
 */
export async function fetchTourneesDisponibles() {
  const res = await fetch(`${API_BASE_URL}/tournees/disponibles`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

/**
 * Affecte une tournée à un conducteur
 * PATCH /tournees/:tourneeId/affecter { conducteur_id }
 */
export async function affecterTourneeConducteur(tourneeId: string, conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/${tourneeId}/affecter`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ conducteur_id: conducteurId }),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

/**
 * Retire une tournée d’un conducteur (remet conducteur_id à NULL)
 * PATCH /tournees/:tourneeId/retirer
 */
export async function retirerTourneeConducteur(tourneeId: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/${tourneeId}/retirer`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({}),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}