import TooltipTest from '../components/ui/TooltipTest';

function App() {
  return (
    <div>
      <TooltipTest />
    </div>
  );
}

export default App;
