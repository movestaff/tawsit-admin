// ✅ Fichier : src/pages/Employes.tsx
// ✅ Fichier : src/pages/Employes.tsx
import React, { useEffect, useState } from 'react'
import { fetchEmployes } from '../lib/api'
import FormulaireEmploye from '../components/FormulaireEmploye'


function Employes() {
  const [employes, setEmployes] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [formVisible, setFormVisible] = useState(false)
  const [selected, setSelected] = useState<any | null>(null)

  // Ajout : état pour le tri
  const [sortBy, setSortBy] = useState<'nom' | 'prenom' | 'matricule' | 'email' | 'actif'>('nom')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc')

  const chargerEmployes = async () => {
    setLoading(true)
    try {
      const data = await fetchEmployes()
      setEmployes(data)
    } catch (err: any) {
      setError(err.message || 'Erreur inconnue')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    chargerEmployes()
  }, [])

  const filteredEmployes = employes.filter((e) => {
  // On ajoute tous les champs visibles, y compris 'actif'
  const actifStr = e.actif ? 'actif oui true 1' : 'inactif non false 0'
  const rowStr = `
    ${e.nom || ''}
    ${e.prenom || ''}
    ${e.matricule || ''}
    ${e.email || ''}
    ${actifStr}
  `.toLowerCase()
  return rowStr.includes(search.toLowerCase())
})

  // Fonction de tri
  const handleSort = (col: typeof sortBy) => {
    if (sortBy === col) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortBy(col)
      setSortOrder('asc')
    }
  }

  // Employés triés selon la colonne et l'ordre
  const sortedEmployes = [...filteredEmployes].sort((a, b) => {
    let valA = a[sortBy]
    let valB = b[sortBy]
    if (sortBy === 'actif') {
      valA = a.actif ? 1 : 0
      valB = b.actif ? 1 : 0
    } else {
      valA = (valA || '').toString().toLowerCase()
      valB = (valB || '').toString().toLowerCase()
    }
    if (valA < valB) return sortOrder === 'asc' ? -1 : 1
    if (valA > valB) return sortOrder === 'asc' ? 1 : -1
    return 0
  })

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-primary mb-6">Gestion des employés</h1>

      {/* Formulaire affiché au-dessus */}
      {formVisible && (
        <div className="mb-6 border rounded p-4 bg-secondary shadow-card transition-all duration-300">
          <FormulaireEmploye
            employe={selected}
            onSuccess={() => {
              setFormVisible(false)
              setSelected(null)
              chargerEmployes()
            }}
            onCancel={() => {
              setFormVisible(false)
              setSelected(null)
            }}
          />
        </div>
      )}

      {/* Recherche + Bouton */}
      {!formVisible && (
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <input
            type="text"
            placeholder="🔍 Rechercher par nom, prénom, matricule, email, Actif..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-3 py-2 border border-neutral rounded shadow-sm w-full max-w-md focus:outline-none focus:ring focus:border-primary"
          />
          <button
            className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded font-semibold transition"
            onClick={() => {
              setFormVisible(true)
              setSelected(null)
            }}
          >
            + Ajouter un employé
          </button>
        </div>
      )}

      {/* Erreurs / Chargement */}
      {loading && <p className="text-gray-700">Chargement des employés...</p>}
      {error && <p className="text-red-600 font-medium">Erreur : {error}</p>}

      {/* Tableau */}
      {!loading && !error && (
        <div className="overflow-x-auto rounded border border-neutral bg-white shadow-card">
          <table className="min-w-full text-sm text-gray-800">
            <thead>
              <tr className="bg-secondary text-left font-semibold text-gray-700">
                <th
                  className="px-4 py-2 cursor-pointer select-none"
                  onClick={() => handleSort('nom')}
                >
                  Nom {sortBy === 'nom' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}
                </th>
                <th
                  className="px-4 py-2 cursor-pointer select-none"
                  onClick={() => handleSort('prenom')}
                >
                  Prénom {sortBy === 'prenom' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}
                </th>
                <th
                  className="px-4 py-2 cursor-pointer select-none"
                  onClick={() => handleSort('matricule')}
                >
                  Matricule {sortBy === 'matricule' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}
                </th>
                <th
                  className="px-4 py-2 cursor-pointer select-none"
                  onClick={() => handleSort('email')}
                >
                  Email {sortBy === 'email' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}
                </th>
                <th
                  className="px-4 py-2 cursor-pointer select-none"
                  onClick={() => handleSort('actif')}
                >
                  Actif {sortBy === 'actif' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedEmployes.map((e) => (
                <tr
                  key={e.ID}
                  className="border-t hover:bg-secondary/80 cursor-pointer"
                  onDoubleClick={() => {
                    setSelected(e)
                    setFormVisible(true)
                  }}
                >
                  <td className="px-4 py-2">{e.nom}</td>
                  <td className="px-4 py-2">{e.prenom || '—'}</td>
                  <td className="px-4 py-2">{e.matricule}</td>
                  <td className="px-4 py-2">{e.email || '—'}</td>
                  <td className="px-4 py-2">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        e.actif ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                      }`}
                    >
                      {e.actif ? 'Actif' : 'Inactif'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <p className="text-xs text-gray-500 p-2">
            Total : {sortedEmployes.length} employé(s)
          </p>
        </div>
      )}
    </div>
  )
}

export default Employes
