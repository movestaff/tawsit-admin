import React, { useRef, useState } from 'react'
import { Button } from './ui/button'
import { toast } from 'react-toastify'

interface Props {
  employeId: string
  photoUrl?: string
  onPhotoUploaded: (url: string) => void
}

const PhotoUploader: React.FC<Props> = ({ employeId, onPhotoUploaded }) => {
  const inputRef = useRef<HTMLInputElement>(null)
  const [loading, setLoading] = useState(false)

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setLoading(true)
    const formData = new FormData()
    formData.append('photo', file)
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/employes/${employeId}/photo`, {
        method: 'POST',
        body: formData
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || "Erreur lors de l'upload")
      }
      const { photoUrl } = await res.json()
      onPhotoUploaded(photoUrl)
      toast.success('Photo mise à jour !')
    } catch (err: any) {
      toast.error(err.message || "Erreur lors de l'upload")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col items-center gap-2 mb-4">
      <Button
        type="button"
        disabled={loading}
        onClick={() => inputRef.current?.click()}
        className="text-sm"
      >
        {loading ? "Envoi..." : "Changer la photo"}
      </Button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  )
}

export default PhotoUploader
