import React, { useEffect, useState } from 'react'
import { Input } from '../components/ui/input'
import { Button } from '../components/ui/button'
import { Switch } from '../components/ui/switch'
import { ajouterEmploye, updateEmploye, deleteEmploye } from '../lib/api'
import { toast } from 'react-toastify'
import AffectationsEmploye from './AffectationsEmploye'
import AffectationForm from './AffectationForm'
import PhotoUploader from './PhotoUploader'

interface Props {
  employe?: any
  onSuccess: () => void
  onCancel?: () => void
}

const FormulaireEmploye: React.FC<Props> = ({ employe, onSuccess, onCancel }) => {
  const [form, setForm] = useState({
    nom: '',
    prenom: '',
    matricule: '',
    email: '',
    telephone: '',
    adresse: '',
    ville: '',
    pays: '',
    service: '',
    departement: '',
    actif: true,
    photo: ''
  })

  const [showAffectation, setShowAffectation] = useState(false)
  const [refreshAffectations, setRefreshAffectations] = useState(false)

  useEffect(() => {
    if (employe) {
      setForm({
        nom: employe.nom || '',
        prenom: employe.prenom || '',
        matricule: employe.matricule || '',
        email: employe.email || '',
        telephone: employe.telephone || '',
        adresse: employe.adresse || '',
        ville: employe.ville || '',
        pays: employe.pays || '',
        service: employe.service || '',
        departement: employe.departement || '',
        actif: employe.actif ?? true,
        photo: employe.photo || ''
      })
    }
  }, [employe])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setForm(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async () => {
    if (!form.nom || !form.matricule) {
      toast.error('Les champs nom et matricule sont obligatoires.')
      return
    }

    const payload = {
      ...form,
      email: form.email?.trim() || null,
    }

    try {
      if (employe) {
        await updateEmploye(employe.ID, payload)
        toast.success('Employé mis à jour.')
        onSuccess()
      } else {
        await ajouterEmploye(payload)
        toast.success('Employé ajouté avec succès !')
        onSuccess()
      }
    } catch (e: any) {
      if (e.message?.includes('employes_email_key')) {
        toast.error("Cet e-mail est déjà utilisé par un autre employé.")
      } else {
        toast.error('Erreur lors de la sauvegarde.')
      }
    }
  }

  const handleDelete = async () => {
    if (!employe) return
    const confirm = window.confirm('Supprimer cet employé ? Cette action est irréversible.')
    if (!confirm) return

    try {
      await deleteEmploye(employe.ID)
      toast.success('Employé supprimé.')
      onSuccess()
    } catch (e: any) {
      toast.error(e.message || 'Suppression impossible.')
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full">
      {/* ------ Colonne gauche : formulaire ------ */}
      <form className="md:col-span-2 space-y-4 bg-white border rounded shadow p-6">
        <h2 className="text-xl font-semibold mb-4">
          {employe ? `Modifier l’employé : ${employe.nom}` : 'Ajouter un nouvel employé'}
        </h2>

        {/* Photo/avatar à gauche + nom/prénom horizontal */}
        <div className="flex items-center gap-6 mb-6">
          {/* Avatar/photo à gauche */}
          <div className="flex-shrink-0 flex flex-col items-center">
            <img
              src={
                form.photo
                  ? form.photo
                  : `https://ui-avatars.com/api/?name=${encodeURIComponent(form.prenom || '')}+${encodeURIComponent(form.nom || '')}&background=228B22&color=fff&size=128`
              }
              alt="Photo ou avatar de l'employé"
              className="w-32 h-32 rounded-full object-cover border-2 border-primary shadow mb-2"
              style={{ minWidth: 96, minHeight: 96 }}
            />
            {employe?.ID && (
              <PhotoUploader
                employeId={employe.ID}
                photoUrl={form.photo}
                onPhotoUploaded={(url) => setForm(prev => ({ ...prev, photo: url }))}
              />
            )}
          </div>
          {/* Nom et prénom à droite, alignés horizontalement */}
          <div className="flex gap-4 items-center w-full">
            <Input
              id="nom"
              name="nom"
              value={form.nom}
              onChange={handleChange}
              placeholder="Nom"
              className="font-bold text-lg"
            />
            <Input
              id="prenom"
              name="prenom"
              value={form.prenom}
              onChange={handleChange}
              placeholder="Prénom"
              className="font-bold text-lg"
            />
          </div>
        </div>

        {/* Les autres champs, tous avec placeholder */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input id="matricule" name="matricule" value={form.matricule} onChange={handleChange} placeholder="Matricule" />
          <Input id="email" name="email" value={form.email} onChange={handleChange} placeholder="Email" />
          <Input id="telephone" name="telephone" value={form.telephone} onChange={handleChange} placeholder="Téléphone" />
          <Input id="adresse" name="adresse" value={form.adresse} onChange={handleChange} placeholder="Adresse" />
          <Input id="ville" name="ville" value={form.ville} onChange={handleChange} placeholder="Ville" />
          <Input id="pays" name="pays" value={form.pays} onChange={handleChange} placeholder="Pays" />
          <Input id="service" name="service" value={form.service} onChange={handleChange} placeholder="Service" />
          <Input id="departement" name="departement" value={form.departement} onChange={handleChange} placeholder="Département" />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 mt-2">
          <div className="flex items-center gap-3">
            <span className="text-gray-700 font-medium">Statut</span>
            <Switch checked={form.actif} onChange={(val) => setForm({ ...form, actif: val })} />
            <span>{form.actif ? 'Actif' : 'Inactif'}</span>
          </div>
          <div className="flex gap-3 ml-auto">
            {employe && (
              <Button type="button" className="bg-orange-600 hover:bg-orange-700 text-white" onClick={handleDelete}>
                Supprimer
              </Button>
            )}
            {onCancel && (
              <Button type="button" variant="outline" onClick={onCancel}>
                Fermer la fiche
              </Button>
            )}
            <Button type="button" className="bg-primary text-white" onClick={handleSubmit}>
              {employe ? 'Mettre à jour' : 'Enregistrer'}
            </Button>
          </div>
        </div>
      </form>

      {/* ------ Colonne droite : affectations et formulaire d'affectation ------ */}
      <div className="md:col-span-1">
        {employe && (
          <div className="bg-white border rounded shadow p-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-semibold">Tournées affectées</h3>
              <Button
                type='button'
                variant="outline"
                className="text-sm"
                onClick={() => setShowAffectation(!showAffectation)}
              >
                {showAffectation ? 'Fermer le formulaire' : '➕ Affecter une tournée'}
              </Button>
            </div>

            <AffectationsEmploye
              employeId={employe.ID}
              key={refreshAffectations.toString()}
            />

            {showAffectation && (
              <div className="mt-4">
                <AffectationForm
                  employeId={employe.ID}
                  onAffectationComplete={() => {
                    setRefreshAffectations(prev => !prev)
                    setShowAffectation(false)
                  }}
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default FormulaireEmploye