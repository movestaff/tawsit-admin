import { useAuthStore } from '../store/authStore'
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL


if (!API_BASE_URL) {
  throw new Error('❌ VITE_API_BASE_URL non défini dans .env')
}



// ✅ Injecte automatiquement le token et la société via les headers requis par le middleware backend
export function getAuthHeaders(contentType?: string) : Record<string, string> {
  const token = localStorage.getItem('token') || ''
  const societe_id = localStorage.getItem('selectedSocieteId') || ''
  const headers: Record<string, string> = {
    'Authorization': `Bearer ${token}`,
    'x-societe-id': societe_id
  }
  if (contentType) {
    headers['Content-Type'] = contentType
  }
  return headers
}

// ✅ Pour usage dans le body uniquement si nécessaire
function getSocieteId() {
  return localStorage.getItem('selectedSocieteId') || ''
}



// ===== Utilitaire de délai d'attente =====
function timeout(ms: number) {
  return new Promise((_, reject) =>
    setTimeout(() => reject(new Error('⏳ Délai dépassé')), ms)
  )
}

// ================== TOURNEES ==================
export async function fetchTournees() {
  const res = await fetch(`${API_BASE_URL}/tournees`, {
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function ajouterTournee(tournee: any) {
  const res = await fetch(`${API_BASE_URL}/tournees`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(tournee),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function updateTournee(id: string, tournee: any) {
  const res = await fetch(`${API_BASE_URL}/tournees/${id}`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(tournee),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function deleteTournee(id: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== CONDUCTEURS ==================
// Liste des conducteurs pour les tournées
export async function fetchConducteurs() {
  const res = await fetch(`${API_BASE_URL}/tournees/conducteurs`, {
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

export async function fetchConducteurGestion() {
  const res = await fetch(`${API_BASE_URL}/conducteurs`, {
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}



// Ajouter un conducteur
export async function ajouterConducteur(conducteur: any) {
  const res = await fetch(`${API_BASE_URL}/conducteurs`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(conducteur),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Update conducteur
export async function updateConducteur(id: string, conducteur: any) {
  const res = await fetch(`${API_BASE_URL}/conducteurs/${id}`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(conducteur),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Delete conducteur
export async function deleteConducteur(id: string) {
  const res = await fetch(`${API_BASE_URL}/conducteurs/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== AFFECTATIONS TOURNEES CONDUCTEUR ==================
// Liste tournées affectées
export async function fetchAffectationsConducteur(conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/affectations-conducteur/${conducteurId}`)
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Affecter à une tournée

// Retirer une affectation
export async function retirerAffectationConducteur(id: string) {
  const res = await fetch(`${API_BASE_URL}/affectations-conducteur/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== VEHICULES ==================
// Liste des véhicules
export async function fetchVehicules() {
  const res = await fetch(`${API_BASE_URL}/vehicules`, {
    method: 'GET'
    , headers: getAuthHeaders('application/json'),})
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Ajouter un véhicule (optionnel)
export async function ajouterVehicule(vehicule: any) {
  const res = await fetch(`${API_BASE_URL}/vehicules`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(vehicule),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function updateVehicule(id: string, vehicule: any) {
  const res = await fetch(`${API_BASE_URL}/vehicules/${id}`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(vehicule),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function deleteVehicule(id: string) {
  const res = await fetch(`${API_BASE_URL}/vehicules/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ================== AFFECTATIONS VEHICULES CONDUCTEUR ==================
// Liste des véhicules affectés à un conducteur
export async function fetchVehiculesAffectes(conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/conducteur-vehicule/${conducteurId}`, {
    method: 'GET'
    , headers: getAuthHeaders('application/json'),})
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
// Affecter véhicule à conducteur
export async function affecterVehiculeConducteur(payload: { conducteur_id: string, vehicule_id: string }) {
  const res = await fetch(`${API_BASE_URL}/conducteur-vehicule`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const err = await res.text()
    throw new Error(err || 'Erreur lors de l’affectation véhicule')
  }
  return res.json()
}
// Retirer affectation véhicule
export async function retirerAffectationVehiculeConducteur(id: string) {
  const res = await fetch(`${API_BASE_URL}/conducteur-vehicule/${id}`, {
    method: 'DELETE',
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// =======================EMPLOYES=================
export async function fetchEmployes() {
  const res = await fetch(`${API_BASE_URL}/employes`,{ method: 'GET', headers: getAuthHeaders('application/json') })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function ajouterEmploye(employe: any) {
  const res = await fetch(`${API_BASE_URL}/employes`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(employe),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function updateEmploye(id: string, employe: any) {
  const res = await fetch(`${API_BASE_URL}/employes/${id}`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(employe),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function deleteEmploye(id: string) {
  const res = await fetch(`${API_BASE_URL}/employes/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// =======================AFFECTATIONS EMPLOYE==================
export async function fetchAffectationsEmploye(employeId: string) {
  const res = await fetch(`${API_BASE_URL}/affectations/${employeId}`, {
    method: 'GET'
    , headers: getAuthHeaders('application/json'),})
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}
export async function ajouterAffectation(payload: {
  employe_id: string,
  type: 'fixe' | 'flexible',
  point_arret_id?: string,
  tournee_id: string,
  ordre_embarquement?: number
} 
) {
  const res = await fetch(`${API_BASE_URL}/affectations`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const err = await res.text()
    throw new Error(err || 'Erreur lors de l’affectation')
  }
  return res.json()
}
export async function retirerAffectation(id: string, type: 'fixe' | 'flexible') {
  const res = await fetch(`${API_BASE_URL}/affectations/${id}?type=${type}`, {
    method: 'DELETE',
    headers: getAuthHeaders('application/json'),  
  })
  if (!res.ok) {
    const errText = await res.text()
    throw new Error(errText || 'Erreur lors de la suppression')
  }
  return res.json()
}
export async function updateAffectation(id: string, payload: { type: 'fixe' | 'flexible', point_arret_id?: string, ordre_embarquement?: number }) {
  const response = await fetch(`${API_BASE_URL}/affectations/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(payload),
  })
  const data = await response.json()
  if (!response.ok) {
    throw new Error(data.error || 'Erreur lors de la mise à jour de l’affectation')
  }
  return data
}



// ================== AFFECTATIONS TOURNEES CONDUCTEUR ==================
/**
 * Récupère la liste des tournées affectées à un conducteur (champ conducteur_id)
 * Appelle l'endpoint : GET /tournees/conducteur/:conducteurId
 */
export async function fetchTourneesParConducteur(conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/conducteur/${conducteurId}`,{
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

/**
 * Récupère la liste des tournées NON affectées à un conducteur (conducteur_id null)
 * Appelle l'endpoint : GET /tournees/disponibles
 */
export async function fetchTourneesDisponibles() {
  const res = await fetch(`${API_BASE_URL}/tournees/disponibles`,{
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  } )
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

/**
 * Affecte une tournée à un conducteur
 * PATCH /tournees/:tourneeId/affecter { conducteur_id }
 */
export async function affecterTourneeConducteur(tourneeId: string, conducteurId: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/${tourneeId}/affecter`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify({ conducteur_id: conducteurId }),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

/**
 * Retire une tournée d’un conducteur (remet conducteur_id à NULL)
 * PATCH /tournees/:tourneeId/retirer
 */
export async function retirerTourneeConducteur(tourneeId: string) {
  const res = await fetch(`${API_BASE_URL}/tournees/${tourneeId}/retirer`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify({}),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

//=========================================================


// 🔐 Fonction de login pour l'application web
export async function loginWeb(email: string, password: string) {
  const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/authM/login-multi`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ email, password })
  })

  const data = await response.json()

  if (!response.ok) {
    throw new Error(data?.error || 'Erreur lors de la connexion')
  }

  

  return data
}


//Affectation tournee/ point d'arrêt à un employé

export async function ajouterAffectationEmploye(payload: any) {
  const res = await fetch(`${API_BASE_URL}/affectations`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'), // ✅ Inclut token + x-societe-id
    body: JSON.stringify(payload),
  })

  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors de l’affectation')
  }

  return res.json()
}

// ✅ Récupération des tournées avec authentification
export async function fetchTourneesAvecAuth() {
  const res = await fetch(`${API_BASE_URL}/tournees`, {
    method: 'GET',
    headers: getAuthHeaders('application/json'), // inclut token + x-societe-id
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

// ✅ Récupération des points d’arrêt pour une tournée donnée
export async function fetchPointsArretAvecAuth(tourneeId: string) {
  if (!tourneeId || typeof tourneeId !== 'string' || tourneeId.trim() === '' || tourneeId === 'undefined') {
    throw new Error('tournee_id non valide')
  }

  const url = `${API_BASE_URL}/points-arret?tournee_id=${encodeURIComponent(tourneeId)}`

  const res = await fetch(url, {
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  })

  if (!res.ok) {
    let errorMsg = 'Erreur inconnue'
    try {
      const errorJson = await res.json()
      errorMsg = JSON.stringify(errorJson)
    } catch (e) {
      errorMsg = await res.text()
    }
    throw new Error(errorMsg)
  }

  return res.json()
}

// ================== UPLOAD PHOTO EMPLOYE ==================
// 🔼 Uploader une photo d'employé via l'API sécurisée
export const uploadPhotoEmploye = async (employeId: string, file: File): Promise<string> => {
  const token =
    JSON.parse(localStorage.getItem('supabase.auth.token') || '{}')?.currentSession?.access_token ||
    useAuthStore.getState().token

  const societeId = useAuthStore.getState().selectedSocieteId

  if (!token || !societeId) {
    throw new Error("Authentification ou société non disponible")
  }

  const formData = new FormData()
  formData.append('photo', file)

  const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/employes/${employeId}/photo`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'x-societe-id': societeId,
    },
    body: formData,
  })

  const result = await response.json()

  if (!response.ok) {
    throw new Error(result.error || 'Échec du téléversement')
  }

  return result.photoPath
}


// 🔽 Récupère l’URL de la photo d’un employé depuis l’API (proxy sécurisé)
export const getPhotoEmployeUrl = (employeId: string) => {
  return `${import.meta.env.VITE_API_BASE_URL}/employes/${employeId}/photo`
}

export const fetchPhotoEmployeAsBlob = async (id: string): Promise<string> => {
  const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/employes/${id}/photo`, {
    headers: getAuthHeaders(),
  })
console.log('📡 fetch appel')
  if (!response.ok) throw new Error('Erreur lors du chargement de la photo')

  const blob = await response.blob()
  return URL.createObjectURL(blob)
}

// ================== UPLOAD PHOTO conducteur ============================== ==================

export const uploadPhotoConducteur = async (conducteurId: string, file: File): Promise<string> => {
  const token =
    JSON.parse(localStorage.getItem('supabase.auth.token') || '{}')?.currentSession?.access_token ||
    useAuthStore.getState().token

  const societeId = useAuthStore.getState().selectedSocieteId

  if (!token || !societeId) {
    throw new Error("Authentification ou société non disponible")
  }

  const formData = new FormData()
  formData.append('photo', file)

  const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/conducteurs/${conducteurId}/photo`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'x-societe-id': societeId,
    },
    body: formData,
  })

  const result = await response.json()

  if (!response.ok) {
    throw new Error(result.error || 'Échec du téléversement')
  }

  return result.photoPath
}


// 🔽 Récupère l’URL de la photo d’un conducteur depuis l’API (proxy sécurisé)
export const getPhotoConducteurUrl = (conducteurId: string) => {
  return `${import.meta.env.VITE_API_BASE_URL}/conducteurs/${conducteurId}/photo`
}

export const fetchPhotoConducteurAsBlob = async (id: string): Promise<string> => {
  const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/conducteurs/${id}/photo`, {
    headers: getAuthHeaders(),
  })
console.log('📡 fetch appel')
  if (!response.ok) throw new Error('Erreur lors du chargement de la photo')

  const blob = await response.blob()
  return URL.createObjectURL(blob)
}



// ================================✅ POINTS D'ARRET – API================================================


// ✅ Ajouter un point d’arrêt
export const ajouterPointArret = async (point: any) => {
  const res = await fetch(`${API_BASE_URL}/points-arret`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(point),
  })

  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors de l’ajout du point')
  }

  return await res.json()
}

// ✅ Modifier un point d’arrêt
export const updatePointArret = async (id: string, data: any) => {
  const res = await fetch(`${API_BASE_URL}/points-arret/${id}`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(data),
  })

  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors de la mise à jour du point')
  }

  return await res.json()
}

// ✅ Supprimer un point d’arrêt
export const deletePointArret = async (id: string) => {
  const res = await fetch(`${API_BASE_URL}/points-arret/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders('application/json'),
  })

  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors de la suppression du point')
  }

  return true
}

// ✅ Récupérer les points d’arrêt liés à une tournée
export const fetchPointsArretParTournee = async (tourneeId: string) => {
  const res = await fetch(`${API_BASE_URL}/points-arret?tournee_id=${tourneeId}`, {
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  })

  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors du chargement des points d’arrêt')
  }

  return await res.json()
}
 // ✅ Récupérer tous les points d’arrêt
export async function fetchPointsArret() {
  const res = await fetch(`${API_BASE_URL}/points-arret`, {
    method: 'GET',
    headers: getAuthHeaders('application/json'), // inclut token + x-societe-id
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}


//=====================Geocoding Adresse========================
export async function geocodeAdresse(adresse: string): Promise<{ lat: number, lng: number } | null> {
  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(adresse)}`
  const res = await fetch(url)
  const data = await res.json()

  if (data && data.length > 0) {
    return {
      lat: parseFloat(data[0].lat),
      lng: parseFloat(data[0].lon)
    }
  }

  return null
}


//=================recupérer les positions des conducteurs========================

export async function fetchPositionsConducteurs() {
   const res = await fetch(`${API_BASE_URL}/tournees/positions`,  {
    method: 'GET',
    headers: getAuthHeaders('application/json'), // inclut Authorization et x-societe-id
  })

  if (!res.ok) throw new Error(await res.text())
  return res.json()
}



// ================== PLANIFICATIONS ==================

/**
 * Récupère toutes les planifications (interface web admin)
 * GET /planifications/admin
 */
export async function fetchPlanifications() {
  const res = await fetch(`${API_BASE_URL}/planifications`, {
    method: 'GET',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

/**
 * Ajoute une nouvelle planification
 * POST /planifications/admin
 */
export async function ajouterPlanification(planification: any) {
  const res = await fetch(`${API_BASE_URL}/planifications`, {
    method: 'POST',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(planification),
  })
  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors de l’ajout de la planification')
  }
  return res.json()
}

/**
 * Met à jour une planification
 * PUT /planifications/admin/:id
 */
export async function updatePlanification(id: string, planification: any) {
  const res = await fetch(`${API_BASE_URL}/planifications/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify(planification),
  })
  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors de la mise à jour de la planification')
  }
  return res.json()
}

/**
 * Supprime une planification
 * DELETE /planifications/admin/:id
 */
export async function deletePlanification(id: string) {
  const res = await fetch(`${API_BASE_URL}/planifications/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders('application/json'),
  })
  if (!res.ok) throw new Error(await res.text())
  return true
}

/**
 * Active ou désactive une planification
 * PATCH /planifications/admin/:id/toggle
 */
export async function togglePlanification(id: string, active: boolean) {
  const res = await fetch(`${API_BASE_URL}/planifications/${id}/toggle`, {
    method: 'PATCH',
    headers: getAuthHeaders('application/json'),
    body: JSON.stringify({ active }),
  })
  if (!res.ok) {
    const err = await res.json()
    throw new Error(err.error || 'Erreur lors de l’activation/désactivation')
  }
  return res.json()
}
