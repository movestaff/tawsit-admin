import React, { useEffect, useState } from 'react'
import { fetchPointsArretParTournee } from '../lib/api'
import { Button } from '../components/ui/button'
import { Card } from '../components/ui/card'
import ModalEditionPointArret from './ModalEditionPointArret'

interface Props {
  tourneeId: string
}

const ListePointsArret: React.FC<Props> = ({ tourneeId }) => {
  const [pointsArret, setPointsArret] = useState<any[]>([])
  const [selectedPoint, setSelectedPoint] = useState<any>(null)
  const [openModal, setOpenModal] = useState(false)

  const fetchPoints = async () => {
    try {
      const res = await fetchPointsArretParTournee(tourneeId)
      setPointsArret(res)
    } catch (error) {
      console.error("Erreur chargement points d'arrêt:", error)
    }
  }

  useEffect(() => {
    fetchPoints()
  }, [tourneeId])

  const handleOpenModal = (point: any) => {
    setSelectedPoint(point)
    setOpenModal(true)
  }

  const handleCloseModal = () => {
    setOpenModal(false)
    setSelectedPoint(null)
    fetchPoints()
  }

  return (
    <div className="space-y-2">
      <h3 className="text-lg font-semibold mb-2">Points d'arrêt</h3>
      {pointsArret.length === 0 ? (
        <p className="text-sm text-gray-500">Aucun point d'arrêt pour cette tournée.</p>
      ) : (
        pointsArret.map(point => (
          <Card key={point.id} className="flex items-center justify-between p-2">
            <div>
              <p className="font-medium">{point.nom}</p>
              <p className="text-sm text-gray-500">Ordre: {point.ordre}</p>
            </div>
            <Button onClick={() => handleOpenModal(point)} size="sm">
              Modifier
            </Button>
          </Card>
        ))
      )}

      {selectedPoint && (
        <ModalEditionPointArret
          pointArret={selectedPoint}
          tournees={[]} // Remplacez ceci par la liste appropriée des tournées si nécessaire
          onUpdated={fetchPoints}
          open={openModal}
          onClose={handleCloseModal}
        />
      )}
    </div>
  )
}

export default ListePointsArret
