// ✅ src/App.tsx
// ✅ src/App.tsx
import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Tournees from './pages/Tournees'
import Carte from './pages/Carte'
import Parametres from './pages/parametres'
import Employes from './pages/Employes'
import Conducteurs from './pages/Conducteurs'
import LoginPage from './pages/LoginPage'
import DashboardLayout from './components/layouts/DashboardLayout'
import PrivateRoute from './components/PrivateRoute'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import SelectSocietePage from './pages/SelectSocietePage'
import 'leaflet/dist/leaflet.css'
import 'leaflet/dist/leaflet.css'
import 'leaflet.markercluster/dist/MarkerCluster.css'
import 'leaflet.markercluster/dist/MarkerCluster.Default.css'
import Planification from './pages/Planification'



function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Page de login SANS layout */}
        <Route path="/" element={<LoginPage />} />

        {/* Pages internes AVEC layout */}
        <Route
          path="/*"
          element={
            <PrivateRoute>
            <DashboardLayout>
              <Routes>
                <Route path="/select-societe" element={<SelectSocietePage />} />
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="carte" element={<Carte />} />
                <Route path="tournees" element={<Tournees />} />
                <Route path="parametres" element={<Parametres />} />
                <Route path="employes" element={<Employes />} />
                <Route path="conducteurs" element={<Conducteurs />} />
                <Route path="planification" element={<Planification />} />
              
                
              </Routes>
            </DashboardLayout>
            </PrivateRoute>
          }
        />
      </Routes>

      <ToastContainer position="bottom-right" autoClose={3000} />
    </BrowserRouter>
  )
}

export default App
